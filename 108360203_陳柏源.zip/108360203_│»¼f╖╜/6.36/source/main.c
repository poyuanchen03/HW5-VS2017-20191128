#include<stdio.h>
#include<stdlib.h>
#define SIZE 30
void strReverse(char[]);
int main(void)
{
	int loop;
	char strArr[SIZE] = "abcdefghijklmnopqrstuvwxyz";
	for (loop = 0; loop < SIZE; loop++)
		printf("%c", strArr[loop]);
	printf("\n");
	strReverse(strArr);
	printf("\n");
	system("pause");
	return 0;
}
void strReverse(char strArr[])
{
	if (strArr[0] == '\0')
	{
		return;
	}
	strReverse(&strArr[1]);
	printf("%c", strArr[0]);
}