#include<stdio.h>
#include<stdlib.h>
#include<time.h>

int main(void)
{
	int i, j, run1, run2, run_total;
	int put, put_result[36000];
	int freq[12] = { 0 };
	srand(time(NULL));
	for (put = 1; put <= 36000; put++)
	{
		run1 = rand() % 6 + 1;
		run2 = rand() % 6 + 1;
		run_total = run1 + run2;
		put_result[put] = run_total;
	}
	for (i = 1; i <= 36000; i++)
	{
		freq[put_result[i]]= freq[put_result[i]]+1;
	}
	printf("%s%11s\n", "�I��", "�`����");
	for (j = 2; j <= 12; j++)
	{
		printf("%2d%12d\n", j, freq[j]);
	}
	system("pause");
	return 0;
}