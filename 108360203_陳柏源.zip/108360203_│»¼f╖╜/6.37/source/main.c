#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
int SearchMax(int[], int);
int SearchMini(int[], int);

int main(void)
{
	int arr[10], i, num, maxvalue, value = 0, minivalue;

	printf("�п�J��Ƽ�:");
	scanf("%d", &num);

	printf("\n");
	printf("�Ф��O��J %d �ӼƦr:\n", num);
	for (i = 0; i < num; i++)
	{
		scanf("%d", &arr[i]);
	}
	maxvalue = SearchMax(arr, num);
	minivalue = SearchMini(arr, num);
	printf("�̤j��:%d\n", maxvalue);
	
	printf("�̤p��:%d\n", minivalue);
	system("pause");
}
int SearchMax(int arr[], int num)
{
	int j;
	int value = 0;

	for (j = 0; j < num; j++)
	{
		if (arr[j] > arr[value])
		{
			value = j;
		}
	}
	return arr[value];
}
int SearchMini(int arr[], int num)
{
	int  i;
	int value = 0;

	for (i = 0; i < num; i++)
	{
		if (arr[i] < arr[value])
		{
			value = i;
		}
	}
	return arr[value];
}